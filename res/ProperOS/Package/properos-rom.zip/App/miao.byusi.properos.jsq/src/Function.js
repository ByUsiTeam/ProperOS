const canvas = document.querySelector("#canvas");
const ctx = canvas.getContext("2d");
let functions = []; // 存储输入的函数解析式
let showAxes = true; // 控制是否显示坐标系
const toast = document.getElementById('toast');
let scale = 1; // 图像缩放比例
let lastDistance = 0; // 记录两指缩放时的距离
let isDragging = false; // 标记是否正在拖拽
let startX = 0;
let startY = 0;
let translateX = 0; // 记录图像在x轴方向的平移量
let translateY = 0; // 记录图像在y轴方向的平移量

window.onload = function () {
    // 页面加载时就绘制坐标系（初始状态显示）
    if (showAxes) {
        drawAxes();
    }
    // 初始化提示框的 Materialize 组件（用于显示提示信息）
    M.Tooltip.init(document.querySelectorAll('.tooltipped'));
    // 给画布添加触摸事件监听，实现缩放和平移功能
    canvas.addEventListener('touchstart', handleTouchStart);
    canvas.addEventListener('touchmove', handleTouchMove);
    canvas.addEventListener('touchend', handleTouchEnd);
};

function toggleAxes() {
    showAxes =!showAxes;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    if (showAxes) {
        drawAxes();
    }
    // 后续可以考虑在这里重新绘制已有的函数图像，避免切换坐标系后图像消失，此处暂省略该逻辑
}

function addFunction() {
    const funcStr = document.getElementById("functionInput").value;
    if (funcStr.trim()!== "") {
        functions.push(funcStr);
    }
}

function plotAllFunctions() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    if (showAxes) {
        drawAxes();
    }
    functions.forEach((funcStr, index) => {
        const exprStr = funcStr.replace(/y=/g, "");
        try {
            const func = new Function("x", `return ${exprStr}`);
            ctx.beginPath();
            for (let x = -10; x <= 10; x += 0.1) {
                const y = func(x);
                const xPos = canvas.width / 2 + x * (canvas.width / 20) * scale + translateX;
                const yPos = canvas.height / 2 - y * (canvas.height / 20) * scale + translateY;
                if (x === -10) {
                    ctx.moveTo(xPos, yPos);
                } else {
                    ctx.lineTo(xPos, yPos);
                }
            }
            ctx.strokeStyle = getRandomColor(index); // 给不同函数设置不同颜色，便于区分
            ctx.stroke();
        } catch (error) {
            showToast(`第${index + 1}个输入的函数解析式无效，请重新输入。`);
        }
    });
}

function drawAxes() {
    // 绘制坐标轴线
    ctx.beginPath();
    ctx.moveTo(canvas.width / 2, 0);
    ctx.lineTo(canvas.width / 2, canvas.height);
    ctx.moveTo(0, canvas.height / 2);
    ctx.lineTo(canvas.width, canvas.height / 2);
    ctx.stroke();

    // 绘制坐标轴刻度和标签
    for (let x = -10; x <= 10; x++) {
        const xPos = canvas.width / 2 + x * (canvas.width / 20) * scale + translateX;
        ctx.beginPath();
        ctx.moveTo(xPos, canvas.height / 2 - 5);
        ctx.lineTo(xPos, canvas.height / 2 + 5);
        ctx.stroke();
        ctx.fillText(x.toString(), xPos - 3, canvas.height / 2 + 15);
    }
    for (let y = -10; y <= 10; y++) {
        const yPos = canvas.height / 2 - y * (canvas.height / 20) * scale + translateY;
        ctx.beginPath();
        ctx.moveTo(canvas.width / 2 - 5, yPos);
        ctx.lineTo(canvas.width / 2 + 5, yPos);
        ctx.stroke();
        ctx.fillText(y.toString(), canvas.width / 2 + 10, yPos + 3);
    }
}

function getRandomColor(index) {
    const colors = [
        'rgb(255, 0, 0)',
        'rgb(0, 255, 0)',
        'rgb(0, 0, 255)',
        'rgb(255, 255, 0)',
        'rgb(0, 255, 255)',
        'rgb(255, 0, 255)'
    ];
    return colors[index % colors.length];
}

function showToast(message) {
    toast.textContent = message;
    toast.classList.add('show');
    setTimeout(() => {
        toast.classList.remove('show');
    }, 2500);
}

function handleTouchStart(event) {
    event.preventDefault();
    if (event.touches.length === 1) {
        isDragging = true;
        startX = event.touches[0].pageX;
        startY = event.touches[0].pageY;
    } else if (event.touches.length === 2) {
        const touch1 = event.touches[0];
        const touch2 = event.touches[1];
        lastDistance = Math.sqrt(Math.pow(touch2.pageX - touch1.pageX, 2) + Math.pow(touch2.pageY - touch1.pageY, 2));
    }
}

function handleTouchMove(event) {
    event.preventDefault();
    if (isDragging) {
        const dx = event.touches[0].pageX - startX;
        const dy = event.touches[0].pageY - startY;
        startX = event.touches[0].pageX;
        startY = event.touches[0].pageY;
        translateX += dx;
        translateY += dy;
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        if (showAxes) {
            drawAxes();
        }
        plotAllFunctions();
    } else if (event.touches.length === 2) {
        const touch1 = event.touches[0];
        const touch2 = event.touches[1];
        const currentDistance = Math.sqrt(Math.pow(touch2.pageX - touch1.pageX, 2) + Math.pow(touch2.pageY - touch1.pageY, 2));
        const scaleFactor = currentDistance / lastDistance;
        scale *= scaleFactor;
        lastDistance = currentDistance;
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        if (showAxes) {
            drawAxes();
        }
        plotAllFunctions();
    }
}

function handleTouchEnd(event) {
    event.preventDefault();
    isDragging = false;
}