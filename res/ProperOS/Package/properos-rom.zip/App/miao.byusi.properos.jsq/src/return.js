window.addEventListener('popstate', () => {
  // 执行返回上一页面的逻辑，例如通过历史记录后退
  history.back();
});