let startX = 0;
let currentX = 0;
const pageContainer = document.getElementById('page - container');
pageContainer.addEventListener('touchstart', (e) => {
  startX = e.touches[0].clientX;
});
pageContainer.addEventListener('touchmove', (e) => {
  currentX = e.touches[0].clientX;
  const translateX = currentX - startX;
  pageContainer.style.transform = `translateX(${translateX}px)`;
});
pageContainer.addEventListener('touchend', () => {
  // 根据滑动距离判断是否切换页面
  if (currentX - startX > 100) {
    // 向左滑动切换页面，这里需要添加具体的页面切换逻辑
  } else if (startX - currentX > 100) {
    // 向右滑动切换页面，这里需要添加具体的页面切换逻辑
  } else {
    pageContainer.style.transform = 'translateX(0)';
  }
});