// 模拟公告数据
const announcements = [
      {
              title: "Beta-3.5.01版本更新内容",
                  date: "2025-01-13",
                      content: "本次更新新增了科学计算器功能（因为该功能无法适配新版顶栏，故使用旧版），新增了应用内更新公告。"
      },
        {
                title: "Beta-3.4.74版本更新内容",
                    date: "2025-01-12",
                        content: "推出了全新的函数解析式显示器功能，优化了应用内文案。"
        },
          {
                  title: "Beta-3.73版本更新内容",
                      date: "2025-01-11",
                          content: "本次内容更换了应用名称，重置大部分页面并均为本地页面，不用担心无法连接问题。优化了按键点击效果，新增关于页面、开源信息页面（使用AGPL V3.0开源），新增日期计算。由于本版本是完全重置版本，因此已安卓2.0版本的用户需要卸载重新安装。"
          },
            {
                    title: "Beta-2.0版本更新内容",
                        date: "2024-08-13",
                            content: "本次内容新增顶栏，新增高级计算功能。"
            },
              {
                      title: "Beta-0.0.1版本更新内容",
                          date: "2024-08-10",
                              content: "这是这个项目的第一个版本，第一次使用时需要联网。"
              }
];

// 获取公告容器元素
const announcementContainer = document.querySelector('.announcement-container');

// 生成公告
announcements.forEach(announcement => {
      const div = document.createElement('div');
        div.classList.add('announcement');

          const h2 = document.createElement('h2');
            h2.textContent = announcement.title;

              const span = document.createElement('span');
                span.textContent = announcement.date;

                  const p = document.createElement('p');
                    p.textContent = announcement.content;

                      div.appendChild(h2);
                        div.appendChild(span);
                          div.appendChild(p);

                            announcementContainer.appendChild(div);
});
})
              }
            }
          }
        }
      }
]