AppM=计算器=AppM
AppTb=src/appIcon.png=AppTb
AppLj=%gmiao.byusi.properos.jsq/=AppLj
Config=config.json=Config