System=True=System
Ui=bfq2.iyu=Ui
AppTb=$sys/JuOS/logo/properos.png=AppTb
End=false=End