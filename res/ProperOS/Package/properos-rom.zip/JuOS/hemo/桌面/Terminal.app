System=True=System
Ui=terminal.iyu=Ui
AppTb=%@JuOS/ICON/ic_device_matebook_filled.png=AppTb
End=false=End