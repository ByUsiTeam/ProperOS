System=True=System
AppTb=$sys/JuOS/logo/cdifit.png=AppTb
End=false=End
Url=http://www.cdifit.cn=Url