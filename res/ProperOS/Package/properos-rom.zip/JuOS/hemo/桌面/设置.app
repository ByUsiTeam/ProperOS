System=True=System
Ui=设置.iyu=Ui
AppTb=%@JuOS/ICON/ic_app_icon_settings.png=AppTb
End=false=End