System=True=System
AppTb=$sys/JuOS/logo/foxcm.ico=AppTb
End=false=End
Url=http://foxcm.cdifit.cn=Url