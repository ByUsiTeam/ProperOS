System=True=System
Ui=fileManager.iyu=Ui
AppTb=%@System/icon/folder.png=AppTb
End=false=End