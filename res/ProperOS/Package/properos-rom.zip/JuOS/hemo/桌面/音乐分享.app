System=True=System
AppTb=$sys/JuOS/ICON/ic_appicon_gallery3d.png=AppTb
End=false=End
Url=https://www.cdifit.cn/s/e8hq=Url