System=True=System
Ui=bili.iyu=Ui
AppTb=$sys/ProperOS/Src/html/RJS.png=AppTb
End=false=End