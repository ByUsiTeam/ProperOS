System=True=System
Ui=导入插件.iyu=Ui
AppTb=$sys/JuOS/src/img/zy/exit.png=AppTb
End=true=End