System=True=System
Ui=设置壁纸.iyu=Ui
AppTb=$sys/JuOS/src/img/ByUsi/bz.png=AppTb
End=false=End